100 classes (directory), each class (directory) has 100 images.
refer to "apple".
100 classes (directory), each class (directory) has 500 images.
refer to "apple".
100 classes (directory), each class (directory) has a certain number of images, whose size obey the Zipf's law.
refer to "apple".